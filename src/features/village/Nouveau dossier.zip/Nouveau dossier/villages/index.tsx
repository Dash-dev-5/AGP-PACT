import React, { useState, useEffect } from 'react';
import { useForm } from 'react-hook-form';
import { Button, Modal, Row, Spinner, Table, Form } from 'react-bootstrap';
import { useAppDispatch, useAppSelector } from 'app/hooks';
import { toast } from 'react-toastify';
import { zodResolver } from '@hookform/resolvers/zod';
import { useNavigate } from 'react-router-dom';

import { fetchCitiesByTerritory } from 'features/ville/citySlice';
import { fetchProvinces } from 'features/province/provinceSlice';
import { fetchVillages, addNeighborhood } from 'features/village/villageSlice';
import { CreateVillage, Neighborhood } from 'features/village/villageType';
import { createVillageSchema } from 'features/village/villageValidation';
import DeleteVillage from './DeleteVillage';
import UpdateVillage from './UpdateVillage';

export default function Village() {
  const [show, setShow] = useState(false);
  const [idProvince, setIdProvince] = useState('');
  const [idCity, setIdCity] = useState('');
  const dispatch = useAppDispatch();
  const navigate = useNavigate();

  const { provinces } = useAppSelector((state) => state.province);
  const { cities } = useAppSelector((state) => state.Villes);
  const { villages, error, status } = useAppSelector((state) => state.Villages);

  const {
    register,
    handleSubmit,
    reset,
    formState: { errors, isSubmitting }
  } = useForm<CreateVillage>({
    resolver: zodResolver(createVillageSchema),
  });

  useEffect(() => {
    dispatch(fetchProvinces());
  }, [dispatch]);

  useEffect(() => {
    if (idProvince) {
      dispatch(fetchCitiesByTerritory({ id: idProvince }));
    }
  }, [dispatch, idProvince]);

  useEffect(() => {
    if (idCity) {
      dispatch(fetchVillages({ id: idCity }));
    }
  }, [dispatch, idCity]);

  const onSubmit = async (data: CreateNeighborhood) => {
    const toastId = toast.loading('Veuillez patienter...');
    try {
      await dispatch(addNeighborhood(data)).unwrap();
      toast.update(toastId, {
        render: 'Quartier/Village ajouté avec succès',
        type: 'success',
        isLoading: false,
        autoClose: 2000,
      });
      handleClose();
    } catch (error) {
      toast.update(toastId, {
        render: String(error),
        type: 'error',
        isLoading: false,
        autoClose: 3000,
      });
    }
  };

  const handleClose = () => {
    setShow(false);
    reset();
  };

  return (
    <>
      <div className="d-flex justify-content-between mb-3">
        <span className="fs-4">Liste des quartiers/villages</span>
        <Button onClick={() => setShow(true)}>Ajouter</Button>
      </div>

      <Form.Group className="mb-3">
        <Form.Label>Choisir une province</Form.Label>
        <Form.Select value={idProvince} onChange={(e) => {
          setIdProvince(e.target.value);
          setIdCity('');
        }}>
          <option value="">-- Sélectionnez une province --</option>
          {provinces.map((province) => (
            <option key={province.id} value={province.id}>
              {province.name}
            </option>
          ))}
        </Form.Select>
      </Form.Group>

      <Form.Group className="mb-3">
        <Form.Label>Choisir une ville</Form.Label>
        <Form.Select value={idCity} onChange={(e) => setIdCity(e.target.value)}>
          <option value="">-- Sélectionnez une ville --</option>
          {cities.map((city) => (
            <option key={city.id} value={city.id}>
              {city.name}
            </option>
          ))}
        </Form.Select>
      </Form.Group>

      <Table striped bordered hover>
        <thead className="table-dark">
          <tr>
            <th>#</th>
            <th>Nom</th>
            <th>Comité</th>
            <th>Référence</th>
            <th>Action</th>
          </tr>
        </thead>
        <tbody>
          {status === 'loading' && (
            <tr>
              <td colSpan={5} className="text-center">
                <Spinner animation="border" size="sm" />
              </td>
            </tr>
          )}
          {status === 'failed' && (
            <tr>
              <td colSpan={5} className="text-danger text-center">{error}</td>
            </tr>
          )}
          {status === 'succeeded' && villages.length > 0 ? (
            villages.map((village: Neighborhood, index: number) => (
              <tr key={village.id}>
                <td>{index + 1}</td>
                <td>{village.name}</td>
                <td>{village.committeeName}</td>
                <td>{village.referenceNumber}</td>
                <td>
                  <div className="d-flex gap-2 justify-content-center">
                    <UpdateVillage village={village} />
                    <DeleteVillage id={village.id} name={village.name} />
                  </div>
                </td>
              </tr>
            ))
          ) : (
            <tr>
              <td colSpan={5} className="text-center">Aucun quartier/village trouvé</td>
            </tr>
          )}
        </tbody>
      </Table>

      <Modal show={show} onHide={handleClose} centered>
        <Modal.Header closeButton>
          <Modal.Title>Ajouter un quartier/village</Modal.Title>
        </Modal.Header>
        <Modal.Body>
          <form onSubmit={handleSubmit(onSubmit)}>
            <Form.Group className="mb-3">
              <Form.Label>Nom</Form.Label>
              <Form.Control {...register('name')} isInvalid={!!errors.name} />
              <Form.Control.Feedback type="invalid">{errors.name?.message}</Form.Control.Feedback>
            </Form.Group>

            <Form.Group className="mb-3">
              <Form.Label>Ville</Form.Label>
              <Form.Select {...register('city')} defaultValue={idCity}>
                <option value="">-- Sélectionnez une ville --</option>
                {cities.map((city) => (
                  <option key={city.id} value={city.id}>{city.name}</option>
                ))}
              </Form.Select>
              {errors.city && <small className="text-danger">{errors.city.message}</small>}
            </Form.Group>

            <Button variant="primary" type="submit" disabled={isSubmitting}>
              {isSubmitting ? 'Enregistrement...' : 'Enregistrer'}
            </Button>
          </form>
        </Modal.Body>
      </Modal>
    </>
  );
}
